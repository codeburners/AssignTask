<?php
//use App\Calculator\Math;

error_reporting(0);

require('vendor/autoload.php');

//$math = new Math();
$math = new App\Calculator\Math();

if(isset($_SERVER['argv']))
{
	echo $math->processCSV($_SERVER['argv'][1]);
}
else echo "CSV file is not correct";