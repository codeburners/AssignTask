<?php

declare(strict_types=1);

namespace App\Calculator;

class Math
{
	// Currency Rate - Relative to EURO
	var $usd_conv=1.1497;
	
	var $jpy_conv=129.53;
	
	public function convertToEuro($fromCurrency,$amount)
	{
		if($fromCurrency=='JPY')
		{
			//convert jpy to Eur
			$amount=$amount/$this->jpy_conv;
		}
		elseif($fromCurrency=='USD')
		{
			//convert usd to Eur
			$amount=$amount/$this->usd_conv;
		}
		
		return $amount;
	}
	public function convertFromEuro($toCurrency,$amount)
	{
		if($toCurrency=='JPY')
		{
			//convert Eur to jpy
			$amount=$amount * $this->jpy_conv;
		}
		elseif($toCurrency=='USD')
		{
			//convert Eur to usd
			$amount=$amount * $this->usd_conv;
		}
		
		return $amount;
	}
	/*** Function: To process CSV ***/
	/*** var $file must be exact path of csv file ***/
    public function processCSV($file)
	{
		if(!file_exists($file))
			return "Source file is not correct.";
		
		//variables 
		$output_data="";
		//to keep private client transaction
		$private_clients=array();
		//Read File Content
		$csvdata=file($file);
		foreach($csvdata as $line=>$data)
		{
			if(empty($data)) continue;

			//reset commission var
			$commission=0;
			//parse the row as array
			$row=explode(',',$data);
			$row[1]=trim($row[1]);
			
			if(strtolower($row[3])=='deposit')
			{
				//rules for deposit -- commission: .03% = (.03*.01)
				$commission=(float)$row[4]*.03*.01;
			}
			else
			{
				//rules for withdraw -- commission: .5% = (.5*.01)
				if(strtolower($row[2])=='business')
				{
					//business client
					$commission=(float)$row[4]*.5*.01;
				}
				else
				{
					//for private client
					$withdraw_amount=$this->convertToEuro(trim($row[5]),(float)$row[4]);
					
					if($withdraw_amount > 1000)
					{
						//withdraw_amount greater than 1000
						$commission = $this->convertFromEuro(trim($row[5]),(($withdraw_amount - 1000)*.3*.01));
					}
					else
					{
						//$withdraw_amount less than 1000
						
						//year & week of year as index
						//$dayOfWeek=date('w',strtotime($row[0]));
						$currentWeekStart=strtotime("-7 day",strtotime($row[0]));
						
						//client exist in memory
						if(isset($private_clients[$row[1]]))
						{
							//get client data in reverse order
							$clientRecords=array_reverse($private_clients[$row[1]]);
							
							$totalWeekAmount=0;
							for($i=0;$i<3 && $i<count($clientRecords);$i++)
							{
								if($clientRecords[$i][0] >= $currentWeekStart)
								{
									$totalWeekAmount += $clientRecords[$i][1];
								}
							}
							
							if($totalWeekAmount > 1000)
							{
								$commission = $this->convertFromEuro(trim($row[5]),($withdraw_amount*.3*.01));
							}
							elseif(($totalWeekAmount+$withdraw_amount) > 1000)
							{
								$commission = $this->convertFromEuro(trim($row[5]),(($totalWeekAmount+$withdraw_amount-1000)*.3*.01));
							}
/*							if(count($clientRecords) < 3)
							{
								
							}
							else 
								$commission = $this->convertFromEuro(trim($row[5]),($withdraw_amount*.3*.01));
							*/
						}
					}
					//$withdraw_amount - else clause	
					
					//client record in array
					if(!isset($private_clients[$row[1]]))
						$private_clients[$row[1]]=array();
					
					array_push(
						$private_clients[$row[1]],
						array(
							strtotime($row[0]),
							$withdraw_amount
						)
					);
					//client record in array
					
				}
				//else clause
			}

			$output_data .= number_format(round($commission,2),2)."\n";
		}
		//foreach end
		
		return $output_data;
	}//
}
