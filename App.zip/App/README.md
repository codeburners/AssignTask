# Assigned task 

I'm using PHP v-7.2.18.

I have completed the task by following provided rule, where I have generate compose autoload via composer dump-autoload command.
I have design the app to run in CLI mode such as:

 > PHP index.php <file-name.csv>
 
Please Note: CSV file must be upload to server, and in <file-name.csv> parameter you have to write relative/absolute path of csv file and it has to be readable. I have used a directory named file where I have stored the example file here by using name input.csv and also executed the command in CLI mode. I'm using the following command to do the execution of task.
 
  > php index.php file/input.csv
  
 To complete the assigned task: I have used almost 2 hrs (From 10.37AM to 12:44 PM) and also taken 15 mins break within this time.
 